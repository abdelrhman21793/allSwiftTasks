for i in (1...5).reversed(){
//   i = i + 1
    print(i)
}
