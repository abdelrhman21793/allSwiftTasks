//for _ in 1...15 {
//    print("hello" )
//}
//for i in 1...15 {
//    print("hello world \(i)" )
//}
//

//let firstNumber = 12
//for i in 1...12 {
//    print("\(i) * \(firstNumber)  = " , firstNumber * i)
//}
//
//var firstNumber = 12
//var i = 0
//while i <= 12 {
//    print("\(i) * \(firstNumber)  = " , firstNumber * i)
// i = i + 1
//}
//
//var firstNumber = 12
//  var i = 0
//repeat
//{
//     print("\(i) * \(firstNumber)  = " , firstNumber * i)
//    i = i + 1
//}
//while i <= 12
//

//for s in 0..<60{
//    print(s)
//}
//let x = 3
// var y = 1
//for _ in 1...10 {
//   y = y * x
//}
//print(y)
