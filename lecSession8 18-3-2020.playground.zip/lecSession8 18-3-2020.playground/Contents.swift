import UIKit

//var listOfNumber :[Int] = [1 , 2 , 3 , 4]
//var anotherList = listOfNumber
//print(listOfNumber)
//print(anotherList)
//

//var name: String = "abdelrhman hesham saad"
//name.append("h")
//for charachter in name {
//    print(charachter)
//}
//print(name.count)
//name.insert("h", at: 23)
//

//var aString: [String] = ["anutforajaroftuna"]
//if aString == aString.reversed() {
//    print(true )
//}
//else {
//    print(false)
//}
//
//

var aString = "abdelrhman hesham saad khalil eldesouky elsherbiny"

var replacE = ""

for c in aString {
    let chr = "\(c)"
    if chr == "e" || chr == "a"{
        replacE = replacE + "*"
    } else {
        replacE = replacE + chr
    }
}
print(replacE)
