var arrayOfName: [String] = ["ahmed" , "ali "]
//print(arrayOfName)
//arrayOfName[0] = "mohamed"
//print(arrayOfName)
arrayOfName.insert("agola", at: 1)
arrayOfName.append("ahhhh" )
if arrayOfName[0] == "ahmed"{
for i in arrayOfName{
    print("hello" , i)
    
}

}
print(arrayOfName.count)

print(arrayOfName[1])
arrayOfName.remove(at: 2)
if arrayOfName[0] == "ahmed"{
for i in arrayOfName{
    print("hello" , i)
    
}

}
print(arrayOfName.count)
arrayOfName.append("osman")
arrayOfName.append(contentsOf: ["ola" , "alola"])

for i in arrayOfName{
    print("hello" , i)
    
}
arrayOfName.removeAll()
