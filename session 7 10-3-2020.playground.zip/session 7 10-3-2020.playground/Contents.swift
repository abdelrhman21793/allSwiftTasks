var nTime = 5
for _ in 1...nTime {
    print("I will not skip the fundamentals!")
}
print("break")
while 1 <= nTime {
        print("I will not skip the fundamentals!")
    nTime = nTime - 1
}
//
var nNumber = 5
for i in 1...nNumber{
    print(i * i, " = \(i) * \(i)")
}
print("break")

var x = 1
while x <= nNumber {
    print(x * x, " = \(x) * \(x)")
    x = x + 1
}
//
print("break")
let N = 6
var leapYear = 2020
for i in 1...N{
    leapYear = leapYear + 4
    if leapYear % 100 == 0 &&   leapYear % 400 != 0 {
        print(leapYear , "not a leap year")
        
    } else if  leapYear % 4 == 0 {
        print(leapYear )
    }}
  print("         break")
var n = 6
var leapYear1 = 2020
for i in 1...(n * 4){
leapYear1 = leapYear1 + 1
if leapYear1 % 4 == 0 {
    if leapYear1 % 100 == 0 &&   leapYear1 % 400 != 0 {
    print(leapYear1 , "not a leap year")
    } else {
    print(leapYear1)

    }
}
}
print("         break")

var leapYear2 = 2020

while n >= 1 {
    if  leapYear2 % 4 == 0 {
        if leapYear1 % 100 == 0 &&   leapYear1 % 400 != 0 {
        print("not leapyear" , leapYear2)
        } else {
            print(leapYear2)
            n = n - 1
        }
    }
    leapYear2 = leapYear2 + 4
}
