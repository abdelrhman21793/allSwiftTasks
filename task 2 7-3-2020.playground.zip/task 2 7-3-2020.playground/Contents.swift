//let a = 5
//let b = 6
//let c = 3
//let d = 0
//
//if a < b && a < c && a < d {
//    print(" smallest number is \(a)"  )
//} else if b < a && b < c && b < d {
//    print(" smallest number is \(b)"  )
//
//
//} else if c < a && c < b && c < d {
//    print(" smallest number is \(c)"  )
//
//
//} else {
//    print(" smallest number is \(d)"  )
//
//}

//let a = 5
//let b = 6
//let c = 3
//let d = 2
//var smallestNumber = a
//if smallestNumber < b {
//    print(" smallest number is \(a)"  )
//
//}else {
//smallestNumber = b
//}
//if smallestNumber < c {
//        print(" smallest number is \(b)"  )
//
//    }else {
//    smallestNumber = c
//    }
//if smallestNumber < d {
//    print(" smallest number is \(c)"  )
//
//}else {
//smallestNumber = d
//}
//if smallestNumber < a {
//    print(" smallest number is \(d)"  )
//
//}else {
//smallestNumber = a
//}

let a = 5 , b = 4 , c = 3 , d = 0
var minValu = a
if minValu > b {
    minValu = b
}
if minValu > c {
    minValu = c
}
if minValu > d {
    minValu = d
}
print(minValu)
