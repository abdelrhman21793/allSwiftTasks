let randomNumber = 105
if randomNumber % 3 == 0 && randomNumber % 5 == 0 && randomNumber % 7 == 0 {
    
    print("number is divisible by 3, 5 and 7")
} else {
    print("number is not divisible by 3, 5 and 7")
}
