let x = 1
let y = 4
let lowX = 1
let lowY = 1
let highX = 3
let highY = 3
if x  >= lowX && y >= lowY && x <= highX && y <= highY {
    
    print("inside")
} else {
    print("outside")

}

