//Task1: Print all the odd numbers from listOfNumbers.
//Example
//Input:
//var listOfNumbers = [1, 2, 3, 10, 100]
//Output:
//1
//3
var allNumber = [10 , 5 , 20 , 30 , 50 , 3 , 7 ]
for oddNumber in allNumber{
    if oddNumber % 2 != 0 {
        print(oddNumber)
    }
}
