//Task2: Print the sum of all the numbers from listOfNumbers.
//Example
//Input:
//var listOfNumbers = [1, 2, 3, 10, 100]
//Output:
//116
//Hint: Store the sum in a variable. Keep increasing it.
var listOfNumbers = [1, 2, 3, 10, 100]
var sumNumbers: Int = 0
for numbers in listOfNumbers {
        sumNumbers = sumNumbers + numbers
    
}
print(sumNumbers)
