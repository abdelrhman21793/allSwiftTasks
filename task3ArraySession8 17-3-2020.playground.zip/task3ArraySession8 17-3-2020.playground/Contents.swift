//task3: Print all the numbers from listOfNumbers that are located at odd indexes.
//Example
//Input:
//var listOfNumbers = [1, 2, 3, 10, 100]
//Output:
//2
//10
//Hint: Use a while loop and the index subscripts.
var listOfNumbers = [1, 2, 3, 10, 100]

var oddNumber = 1
while oddNumber < listOfNumbers.count {
    print(listOfNumbers[oddNumber])
    oddNumber += 2
}
