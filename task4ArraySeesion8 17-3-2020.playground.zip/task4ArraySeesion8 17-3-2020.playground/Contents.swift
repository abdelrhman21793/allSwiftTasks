//Task4: Print the numbers from listOfNumbers in reverse order on separate lines.
//Example
//Input:
//var listOfNumbers = [1, 2, 3, 10, 100]
//Output:
//100
//10
//3
//2
//1
//Hint: Use a loop that counts from the last index down to the first one.
var listOfNumbers = [1, 2, 3, 10, 100]
var revers = listOfNumbers.count - 1
while revers >= 0  {
    print(listOfNumbers[revers])
    revers = revers - 1
}
